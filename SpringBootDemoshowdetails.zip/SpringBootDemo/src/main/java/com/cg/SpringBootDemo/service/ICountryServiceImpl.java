package com.cg.SpringBootDemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringBootDemo.bean.Country;
import com.cg.SpringBootDemo.dao.ICountryDao;


@Service
public class ICountryServiceImpl  implements ICountryService{


	@Autowired
	ICountryDao countryDao;
	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return countryDao.getAllCountries();
	}

}
