package com.cg.SpringBootDemo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.SpringBootDemo.bean.Country;


@Repository
public class CountryDaoImpl implements ICountryDao{

	@Override
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return CountryDb.getCountryList();
	}

}
