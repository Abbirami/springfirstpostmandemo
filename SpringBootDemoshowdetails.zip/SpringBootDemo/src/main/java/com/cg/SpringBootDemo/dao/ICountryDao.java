package com.cg.SpringBootDemo.dao;

import java.util.List;

import com.cg.SpringBootDemo.bean.Country;



public interface ICountryDao {
	
	public abstract List<Country> getAllCountries();

}
