package com.cg.SpringBootDemo.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.SpringBootDemo.bean.Country;



public class CountryDb {
	
	private static ArrayList<Country> countryList=new ArrayList<Country>();
	
	static {
		countryList.add(new Country("1000","India","3545238"));
		countryList.add(new Country("1002","pakistan","4756468"));
		countryList.add(new Country("1003","SriLanka","8759869"));
		countryList.add(new Country("1004","China","2551889"));
		countryList.add(new Country("1005","USA","36428466"));
	}
	
	public static ArrayList<Country> getCountryList() {
		return countryList;
	}

	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = countryList;
	}

}
