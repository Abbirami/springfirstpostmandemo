package com.cg.SpringBootDemo.service;

import java.util.List;

import com.cg.SpringBootDemo.bean.Country;



public interface ICountryService {

	public List<Country> getAllCountries();

}
